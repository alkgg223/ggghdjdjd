package com.example.gunsmod;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class WorkbenchRecipes {
    public record Cost(Supplier<Item> item, int count) {}

    public record Entry(Supplier<? extends Item> result, int count, GunType gun, List<Cost> costs) {}

    private static List<Entry> cache;

    private static Cost c(Item item, int n) {
        return new Cost(() -> item, n);
    }

    public static List<Entry> all() {
        if (cache == null) {
            List<Entry> l = new ArrayList<>();
            l.add(new Entry(GunsMod.PISTOL, 1, GunType.PISTOL, List.of(c(Items.IRON_INGOT, 8), c(Items.REDSTONE, 2))));
            l.add(new Entry(GunsMod.DEAGLE, 1, GunType.DEAGLE, List.of(c(Items.IRON_INGOT, 14), c(Items.REDSTONE, 3), c(Items.DIAMOND, 1))));
            l.add(new Entry(GunsMod.SMG, 1, GunType.SMG, List.of(c(Items.IRON_INGOT, 12), c(Items.REDSTONE, 3))));
            l.add(new Entry(GunsMod.RIFLE, 1, GunType.RIFLE, List.of(c(Items.IRON_INGOT, 16), c(Items.REDSTONE, 4), c(Items.DIAMOND, 1))));
            l.add(new Entry(GunsMod.M4, 1, GunType.M4, List.of(c(Items.IRON_INGOT, 18), c(Items.REDSTONE, 4), c(Items.DIAMOND, 1))));
            l.add(new Entry(GunsMod.SHOTGUN, 1, GunType.SHOTGUN, List.of(c(Items.IRON_INGOT, 14), c(Items.REDSTONE, 2))));
            l.add(new Entry(GunsMod.SNIPER, 1, GunType.SNIPER, List.of(c(Items.IRON_INGOT, 20), c(Items.REDSTONE, 5), c(Items.DIAMOND, 3))));
            l.add(new Entry(GunsMod.LMG, 1, GunType.LMG, List.of(c(Items.IRON_INGOT, 28), c(Items.REDSTONE, 6), c(Items.DIAMOND, 2))));
            l.add(new Entry(GunsMod.RPG, 1, GunType.RPG, List.of(c(Items.IRON_INGOT, 30), c(Items.GUNPOWDER, 16), c(Items.DIAMOND, 3))));
            l.add(new Entry(GunsMod.MINIGUN, 1, GunType.MINIGUN, List.of(c(Items.IRON_INGOT, 40), c(Items.REDSTONE, 10), c(Items.DIAMOND, 5))));
            int[][] ammo = { // iron, gunpowder, count   (order = GunType order)
                {2, 3, 24}, {3, 4, 14}, {2, 4, 40}, {3, 4, 30}, {3, 4, 30}, {2, 5, 12}, {4, 5, 10}, {4, 6, 50}, {6, 8, 2}, {5, 8, 100}};
            for (GunType t : GunType.values()) {
                int[] a = ammo[t.ordinal()];
                l.add(new Entry(GunsMod.AMMO_ITEMS.get(t), a[2], null, List.of(c(Items.IRON_INGOT, a[0]), c(Items.GUNPOWDER, a[1]))));
            }
            cache = l;
        }
        return cache;
    }

    public static int count(Player p, Item item) {
        int n = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public static void consume(Player p, Item item, int n) {
        for (int i = 0; i < p.getInventory().getContainerSize() && n > 0; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.is(item)) {
                int t = Math.min(s.getCount(), n);
                s.shrink(t);
                n -= t;
            }
        }
    }

    public static boolean canAfford(Player p, List<Cost> costs) {
        if (p.getAbilities().instabuild) return true;
        for (Cost c : costs) {
            if (count(p, c.item().get()) < c.count()) return false;
        }
        return true;
    }

    private WorkbenchRecipes() {}
}
