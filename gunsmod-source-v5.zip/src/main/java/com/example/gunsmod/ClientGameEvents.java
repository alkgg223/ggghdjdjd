package com.example.gunsmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = GunsMod.MODID, value = Dist.CLIENT)
public class ClientGameEvents {
    public static boolean aiming = false;

    private static float aimProg, aimProgO;
    private static float sprintProg, sprintProgO;
    private static float recoilAnim, recoilAnimO;
    private static GunItem lastGun = null;
    private static int lastSlot = -1;
    private static int lastAmmo = -1;

    private static boolean scopeOverlay(ItemStack st, GunItem g) {
        return g.type.scoped || GunItem.getScope(st) == 2;
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        boolean holding = p.getMainHandItem().getItem() instanceof GunItem;
        while (ClientModEvents.RELOAD.consumeClick()) {
            if (holding) PacketDistributor.sendToServer(new ReloadPayload());
        }
        while (ClientModEvents.AIM.consumeClick()) {
            if (holding) {
                aiming = !aiming;
                PacketDistributor.sendToServer(new AimPayload(aiming));
            }
        }
        if (!holding && aiming) {
            aiming = false;
            PacketDistributor.sendToServer(new AimPayload(false));
        }

        aimProgO = aimProg;
        aimProg += ((aiming ? 1f : 0f) - aimProg) * 0.35f;
        boolean sprint = holding && p.isSprinting() && !aiming;
        sprintProgO = sprintProg;
        sprintProg += ((sprint ? 1f : 0f) - sprintProg) * 0.3f;
        recoilAnimO = recoilAnim;
        recoilAnim *= 0.6f;

        // Detect a shot (ammo went down) -> recoil animation + camera kick
        if (holding) {
            ItemStack st = p.getMainHandItem();
            GunItem g = (GunItem) st.getItem();
            int ammo = GunItem.getAmmo(st, g.type);
            int slot = p.getInventory().selected;
            if (slot != lastSlot || g != lastGun) {
                lastSlot = slot;
                lastGun = g;
                lastAmmo = ammo;
            } else {
                if (ammo < lastAmmo) {
                    recoilAnim = 1.0f;
                    float k = g.type.recoil * (aiming ? 0.6f : 1.0f);
                    p.setXRot(p.getXRot() - k);
                    p.setYRot(p.getYRot() + (float) ((Math.random() - 0.5) * k * 0.7));
                }
                lastAmmo = ammo;
            }
        } else {
            lastGun = null;
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        ItemStack held = e.getPlayer().getMainHandItem();
        if (aiming && held.getItem() instanceof GunItem g) {
            float z = g.type.zoom;
            int sc = GunItem.getScope(held);
            if (sc == 1) z *= 0.8f;
            else if (sc == 2 && !g.type.scoped) z *= 0.45f;
            e.setNewFovModifier(e.getNewFovModifier() * z);
        }
    }

    /** First-person gun animation: aim, sprint pose, recoil. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getItemStack().getItem() instanceof GunItem g)) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        float pt = e.getPartialTick();
        float ap = Mth.lerp(pt, aimProgO, aimProg);
        if (scopeOverlay(e.getItemStack(), g) && ap > 0.9f) {
            e.setCanceled(true);
            return;
        }
        float sp = Mth.lerp(pt, sprintProgO, sprintProg);
        float ra = Mth.lerp(pt, recoilAnimO, recoilAnim);
        PoseStack ps = e.getPoseStack();
        ps.translate(-0.40f * ap, 0.12f * ap, 0f);
        ps.translate(0.56f, -0.52f, -0.72f);
        float bob = (float) Math.sin((p.tickCount + pt) * 0.7f) * 2.0f * sp;
        ps.mulPose(Axis.XP.rotationDegrees(-28f * sp + 7f * ra + bob));
        ps.mulPose(Axis.YP.rotationDegrees(28f * sp));
        ps.translate(0f, -0.18f * sp, 0.12f * ra);
        ps.translate(-0.56f, 0.52f, 0.72f);
    }

    /** Sniper scope overlay (drawn under the hotbar). */
    @SubscribeEvent
    public static void onGuiLayer(RenderGuiLayerEvent.Pre e) {
        if (!e.getName().equals(VanillaGuiLayers.CROSSHAIR)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || !(p.getMainHandItem().getItem() instanceof GunItem g)) return;
        if (!scopeOverlay(p.getMainHandItem(), g) || aimProg < 0.9f) return;
        GuiGraphics gg = e.getGuiGraphics();
        int w = gg.guiWidth();
        int h = gg.guiHeight();
        int cx = w / 2;
        int cy = h / 2;
        int r = (int) (h * 0.44f);
        int ri = r - 5;
        for (int y = 0; y < h; y++) {
            int dy = y - cy;
            if (Math.abs(dy) >= r) {
                gg.fill(0, y, w, y + 1, 0xFF000000);
                continue;
            }
            int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
            gg.fill(0, y, cx - hw, y + 1, 0xFF000000);
            gg.fill(cx + hw, y, w, y + 1, 0xFF000000);
            if (Math.abs(dy) >= ri) {
                gg.fill(cx - hw, y, cx + hw, y + 1, 0xFF0B0B0D); // lens rim, top/bottom
            } else {
                int hwi = (int) Math.sqrt((double) ri * ri - (double) dy * dy);
                gg.fill(cx - hw, y, cx - hwi, y + 1, 0xFF0B0B0D);
                gg.fill(cx + hwi, y, cx + hw, y + 1, 0xFF0B0B0D);
                int fade = Math.min(10, hwi);
                gg.fill(cx - hwi, y, cx - hwi + fade, y + 1, 0x55000000); // soft inner shadow
                gg.fill(cx + hwi - fade, y, cx + hwi, y + 1, 0x55000000);
            }
        }
        int thick = Math.max(2, r / 90);
        int gap = Math.max(5, r / 28);
        int post = (int) (r * 0.38f);
        int col = 0xF0000000;
        // thin cross-hairs
        gg.fill(cx - ri + 6, cy, cx - gap, cy + 1, col);
        gg.fill(cx + gap, cy, cx + ri - 6, cy + 1, col);
        gg.fill(cx, cy - ri + 6, cx + 1, cy - gap, col);
        gg.fill(cx, cy + gap, cx + 1, cy + ri - 6, col);
        // thick outer posts
        gg.fill(cx - ri + 6, cy - thick / 2, cx - ri + 6 + post, cy - thick / 2 + thick, col);
        gg.fill(cx + ri - 6 - post, cy - thick / 2, cx + ri - 6, cy - thick / 2 + thick, col);
        gg.fill(cx - thick / 2, cy - ri + 6, cx - thick / 2 + thick, cy - ri + 6 + post, col);
        gg.fill(cx - thick / 2, cy + ri - 6 - post, cx - thick / 2 + thick, cy + ri - 6, col);
        // mil-dots
        int step = Math.max(8, r / 14);
        for (int k = 1; k * step < ri - post; k++) {
            int d = k * step;
            gg.fill(cx - d - 1, cy - 1, cx - d + 1, cy + 2, col);
            gg.fill(cx + d - 1, cy - 1, cx + d + 1, cy + 2, col);
            gg.fill(cx - 1, cy - d - 1, cx + 2, cy - d + 1, col);
            gg.fill(cx - 1, cy + d - 1, cx + 2, cy + d + 1, col);
        }
        gg.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFE02020); // red centre dot
    }

    /** Ammo counter HUD (bottom right): gun name, big magazine count, reserve, fire mode. */
    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui) return;
        ItemStack st = p.getMainHandItem();
        if (!(st.getItem() instanceof GunItem g)) return;
        GuiGraphics gg = e.getGuiGraphics();
        Font font = mc.font;
        int w = gg.guiWidth();
        int h = gg.guiHeight();
        int ammo = GunItem.getAmmo(st, g.type);
        boolean reloading = GunItem.getReload(st) > 0;
        boolean inf = p.getAbilities().instabuild;
        String reserve = inf ? "\u221E" : String.valueOf(GunItem.countAmmo(p, g.type));
        int low = Math.max(1, g.type.magSize / 5);
        int color = reloading ? 0xFF9AA0A8 : (ammo <= low ? 0xFFFF5A5A : 0xFFFFFFFF);
        int right = w - 12;
        int base = h - 14;
        String name = st.getHoverName().getString();
        GunPreview.small(gg, font, name, right - (int) (font.width(name) * 0.85f), base - 52, 0xFFE8E8E8, 0.85f);
        gg.fill(right - 92, base - 41, right, base - 40, 0x66FFFFFF);
        String big = reloading ? "..." : String.valueOf(ammo);
        float bs = 2.6f;
        String mag = "/" + g.type.magSize;
        int magW = (int) (font.width(mag) * 0.8f);
        int bigW = (int) (font.width(big) * bs);
        GunPreview.small(gg, font, big, right - magW - 4 - bigW, base - 36, color, bs);
        GunPreview.small(gg, font, mag, right - magW, base - 34, 0xFF9AA0A8, 0.8f);
        GunPreview.small(gg, font, reserve, right - (int) (font.width(reserve) * 0.9f), base - 20, 0xFFB8C0CC, 0.9f);
        String mode = g.type.automatic ? "AUTO" : "SEMI";
        GunPreview.small(gg, font, mode, right - (int) (font.width(mode) * 0.8f), base - 8, 0xFFE8E8E8, 0.8f);
        int bars = g.type.automatic ? 4 : 1;
        for (int i = 0; i < bars; i++) {
            gg.fill(right - 80 - 12 + i * 3, base - 8, right - 80 - 12 + i * 3 + 1, base, 0xFFE8E8E8);
        }
    }
}
