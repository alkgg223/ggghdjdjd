package com.example.gunsmod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class GunCustomizerScreen extends AbstractContainerScreen<GunCustomizerMenu> {
    private static final String[] SCOPE_NAMES = {"Empty", "Red dot sight", "4x scope"};
    private static final String[] SCOPE_COST = {"Free", "2 iron + 1 redstone", "4 iron + 1 diamond"};
    private int category = 0; // 0 = optic, 1 = finish
    private float yaw = -30f;
    private boolean dragging = false;

    public GunCustomizerScreen(GunCustomizerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 460;
        this.imageHeight = 250;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int catX() { return leftPos + 34; }
    private int catY(int i) { return topPos + 52 + i * 34; }
    private int optX() { return leftPos + 356; }
    private int optY(int i) { return topPos + 46 + i * 24; }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos;
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xF00C1015);
        for (int gx = x; gx < x + imageWidth; gx += 16) g.fill(gx, y, gx + 1, y + imageHeight, 0x10FFFFFF);
        for (int gy = y; gy < y + imageHeight; gy += 16) g.fill(x, gy, x + imageWidth, gy + 1, 0x10FFFFFF);
        ItemStack gun = menu.getSlot(0).getItem();
        boolean has = gun.getItem() instanceof GunItem;
        GunPreview.small(g, font, "\u2022 Customize", x + 8, y + 5, 0xFFE0A030, 0.8f);
        GunPreview.small(g, font, has ? gun.getHoverName().getString() : "Weapon bench", x + 8, y + 15, 0xFFFFFFFF, 1.6f);
        if (has) {
            GunType t = ((GunItem) gun.getItem()).type;
            GunPreview.small(g, font, GunsMod.AMMO_ITEMS.get(t).get().getDescription().getString(), x + 8, y + 36, 0xFF8A919C, 0.8f);
        }
        for (Slot s : menu.slots) {
            g.fill(x + s.x - 1, y + s.y - 1, x + s.x + 17, y + s.y + 17, 0xFF1A2028);
            g.fill(x + s.x, y + s.y, x + s.x + 16, y + s.y + 16, 0xFF0F1318);
        }
        GunPreview.small(g, font, "put weapon", x + 30, y + 35, 0xFF5E6672, 0.7f);

        int curPaint = has ? GunItem.getPaint(gun) : -1;
        int curScope = has ? GunItem.getScope(gun) : -1;
        String[] cats = {"Optic", "Finish"};
        String[] vals = {has ? SCOPE_NAMES[Math.max(0, curScope)] : "-", has ? Paints.NAMES[Math.max(0, curPaint)] : "-"};
        for (int i = 0; i < 2; i++) {
            int cx = catX() - 24, cy = catY(i);
            boolean sel = category == i;
            g.fill(cx, cy, cx + 150, cy + 28, sel ? 0xFF1A2128 : 0xFF11161C);
            if (sel) { g.fill(cx, cy, cx + 150, cy + 1, 0xFFE0A030); g.fill(cx, cy + 27, cx + 150, cy + 28, 0xFFE0A030); }
            g.fill(cx + 6, cy + 7, cx + 20, cy + 21, i == 1 && has ? 0xFF000000 | Paints.COLORS[Math.max(0, curPaint)] : 0xFF3A4450);
            g.drawString(font, cats[i], cx + 28, cy + 5, 0xFFC8CFD8, false);
            g.drawString(font, vals[i], cx + 28, cy + 16, 0xFF8A919C, false);
        }

        int px = x + 186, pw = 160;
        g.fill(px, y + 24, px + pw, y + 128, 0xFF11161C);
        if (has) GunPreview.draw(g, gun, px + pw / 2f, y + 76, 74f, yaw, 8f);
        else GunPreview.small(g, font, "Put a weapon in the slot", px + 24, y + 74, 0xFF5E6672, 1f);
        GunPreview.small(g, font, "drag to rotate", px + 4, y + 118, 0xFF5E6672, 0.7f);

        // stats
        GunPreview.small(g, font, "\u2022 Stats", px, y + 134, 0xFFE0A030, 0.9f);
        if (has) {
            GunType t = ((GunItem) gun.getItem()).type;
            String[] names = {"Damage", "Fire rate", "Recoil", "Accuracy", "Range", "Reload", "Magazine"};
            float dmg = t.damage * t.pellets;
            float[] val = {dmg, 1200f / Math.max(1, t.fireDelay), t.recoil, 100f - t.spread * 8f, (float) t.range, t.reloadTicks / 20f, t.magSize};
            float[] max = {40f, 1200f, 6f, 100f, 200f, 8f, 150f};
            String[] txt = {String.format("%.1f", dmg), String.valueOf((int) val[1]), String.valueOf(t.recoil),
                    String.valueOf((int) val[3]), (int) t.range + "m", String.format("%.1fs", val[5]), String.valueOf(t.magSize)};
            for (int i = 0; i < names.length; i++) {
                int ry = y + 146 + i * 14;
                g.drawString(font, names[i], px, ry, 0xFFB8C0CC, false);
                g.drawString(font, txt[i], px + pw - font.width(txt[i]), ry, 0xFFFFFFFF, false);
                g.fill(px, ry + 10, px + pw, ry + 11, 0xFF2A323C);
                int bw = (int) (pw * Math.max(0.03f, Math.min(1f, val[i] / max[i])));
                g.fill(px, ry + 10, px + bw, ry + 11, 0xFFE8E8E8);
            }
        }

        // option list
        int ox = optX();
        GunPreview.small(g, font, category == 0 ? "\u2022 Optic" : "\u2022 Finish", ox, y + 30, 0xFFE0A030, 0.9f);
        if (category == 0) {
            for (int i = 0; i < 3; i++) {
                int oy = optY(i);
                boolean hov = mx >= ox && mx < ox + 96 && my >= oy && my < oy + 22;
                g.fill(ox, oy, ox + 96, oy + 22, i == curScope ? 0xFF7A5416 : (hov ? 0xFF1E252D : 0xFF11161C));
                g.drawString(font, SCOPE_NAMES[i], ox + 4, oy + 3, 0xFFFFFFFF, false);
                GunPreview.small(g, font, SCOPE_COST[i], ox + 4, oy + 13, 0xFF8A919C, 0.7f);
            }
        } else {
            for (int i = 0; i < Paints.COUNT; i++) {
                int oy = optY(i) - (i > 0 ? 0 : 0) - 4 + 0;
                oy = topPos + 44 + i * 20;
                boolean hov = mx >= ox && mx < ox + 96 && my >= oy && my < oy + 18;
                g.fill(ox, oy, ox + 96, oy + 18, i == curPaint ? 0xFF7A5416 : (hov ? 0xFF1E252D : 0xFF11161C));
                g.fill(ox + 3, oy + 3, ox + 15, oy + 15, 0xFF000000 | Paints.COLORS[i]);
                g.drawString(font, Paints.NAMES[i], ox + 20, oy + 5, 0xFFFFFFFF, false);
            }
        }
        GunPreview.small(g, font, "Drag to rotate \u00B7 Esc to close", x + imageWidth - 150, y + imageHeight - 12, 0xFF5E6672, 0.7f);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        this.renderTooltip(g, mx, my);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            yaw += (float) dx * 1.2f;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < 2; i++) {
            int cx = catX() - 24, cy = catY(i);
            if (mx >= cx && mx < cx + 150 && my >= cy && my < cy + 28) {
                category = i;
                return true;
            }
        }
        if (mx >= leftPos + 186 && mx < leftPos + 346 && my >= topPos + 24 && my < topPos + 128) {
            dragging = true;
            return true;
        }
        boolean hasGun = menu.getSlot(0).getItem().getItem() instanceof GunItem;
        if (hasGun && minecraft != null && minecraft.gameMode != null) {
            int ox = optX();
            if (category == 0) {
                for (int i = 0; i < 3; i++) {
                    int oy = optY(i);
                    if (mx >= ox && mx < ox + 96 && my >= oy && my < oy + 22) {
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 10 + i);
                        return true;
                    }
                }
            } else {
                for (int i = 0; i < Paints.COUNT; i++) {
                    int oy = topPos + 44 + i * 20;
                    if (mx >= ox && mx < ox + 96 && my >= oy && my < oy + 18) {
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, i);
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
